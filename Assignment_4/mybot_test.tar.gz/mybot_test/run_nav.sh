#!/bin/bash

roslaunch mybot_navigation amcl_demo.launch
